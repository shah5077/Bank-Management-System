package bankManagementSystem;

import java.awt.Color;
import java.awt.Image;

import javax.swing.*;

public class Login extends JFrame {
	public Login() {
		setTitle("Automated Teller MAchine");
		setLayout(null);
		 
        setSize(800,480);
		setVisible(true);
		setLocation(350,200);
		
		ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("iconmain/logo.png"));
		Image i2=i1.getImage().getScaledInstance(100, 100, Image.SCALE_DEFAULT);
		ImageIcon i3= new ImageIcon(i2);
        JLabel label=new JLabel(i3);
        
        label.setBounds(70,10, 100,100);
        
        
        add(label);
        
        getContentPane().setBackground(Color.black);
       
	
	}
	
	public static void main(String[] args) {
		new Login();
		
	}

}
